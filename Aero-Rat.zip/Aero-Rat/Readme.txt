file Client.exe: Panel

file Server.exe: connect to 127.0.0.1:81


Build New Server:

1) Open file  /Server/ProjectUnhook.dpr

2) Replace RemoteHost, RemotePort

String 53, 54

3) Compile Delphi 7.